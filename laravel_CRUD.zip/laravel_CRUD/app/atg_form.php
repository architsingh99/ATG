<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class atg_form extends Model
{
    protected $fillable = ['name', 'email', 'pincode'];
}
