<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Update</title>
</head>
<body>
<center>
<h1>UPDATE DETAILS</h1>
    <?php echo e(Form::model($user, ['method'=>'patch', 'action'=>['ATGController@update', $user->id]])); ?>

        <?php echo e(Form::label('name', 'Name')); ?>

        <?php echo e(Form::text('name')); ?>

        <?php echo e(Form::label('email', 'Email')); ?>

        <?php echo e(Form::text('email')); ?>

        <?php echo e(Form::label('pincode', 'Pincode')); ?>

        <?php echo e(Form::text('pincode')); ?>

        <?php echo e(Form::submit('Update')); ?>




   <?php echo e(Form::close()); ?>

    <center>
</body>
</html><?php /**PATH D:\projects_git\laravel_CRUD\resources\views/update.blade.php ENDPATH**/ ?>