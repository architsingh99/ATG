<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Read</title>
</head>
<body>
<h1 style="text-align:center;">User Details</h1>
<br>
<h3><a href="create">Create a new user</a></h3>
    <table style="width:100%;" border="1px">
        <thead>
            <th>Name</th>
            <th>Email</th>
            <th>Pincode</th>
            <th>Creation Date</th>
            <th>Action</th>
        </thead>
        <tbody>
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="text-align:center;">
        <td><?php echo e($users->name); ?></td>
        <td><?php echo e($users->email); ?></td>
        <td><?php echo e($users->pincode); ?></td>
        <td><?php echo e($users->created_at); ?></td>
        <td><a href="edit/<?php echo e($users->id); ?>">Update</a> / <a href="delete/<?php echo e($users->id); ?>">Delete</a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    </body>
</html><?php /**PATH D:\projects_git\laravel_CRUD\resources\views/read.blade.php ENDPATH**/ ?>