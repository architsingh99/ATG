<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<center>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
<h1>ATG FORM</h1>
    <form action="store" method="post">
        <label for="name">Name</label><br>
        <input type="text" name="name"><br>
        <label for="email">Email</label><br>
        <input type="email" name="email"><br>
        <label for="">Pincode</label><br>
        <input type="text" pattern="\d*" name="pincode" maxlength="6"><br>
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
        <input type="submit" value="submit">


    </form>
    <center>
</body>
</html><?php /**PATH D:\projects_git\laravel_CRUD\resources\views/create.blade.php ENDPATH**/ ?>