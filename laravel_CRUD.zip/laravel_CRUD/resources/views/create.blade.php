<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<center>
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif
<h1>ATG FORM</h1>
    <form action="store" method="post">
        <label for="name">Name</label><br>
        <input type="text" name="name"><br>
        <label for="email">Email</label><br>
        <input type="email" name="email"><br>
        <label for="">Pincode</label><br>
        <input type="text" pattern="\d*" name="pincode" maxlength="6"><br>
        <input type="hidden" name="_token" value="{{csrf_token()}}">
        <input type="submit" value="submit">


    </form>
    <center>
</body>
</html>